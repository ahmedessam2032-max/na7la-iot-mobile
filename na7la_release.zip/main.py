import asyncio
import io
import json
import secrets
import base64
import hmac
import hashlib
import re
import sys
import bcrypt

if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, List

from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect, Query, Request, Response
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from config import settings
from database import engine, Base, SessionLocal, get_db
from models import User, Strip, Socket, Schedule, Scene, AuditLog, EnergyLog, SharedAccess
from tcp_server import na7la_hub
from plugins import log_event


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def hash_password(password: str) -> str:
    """تشفير كلمة المرور أو الـ PIN باستخدام bcrypt"""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """التحقق من صحة كلمة المرور المشفرة"""
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def validate_password_strength(password: str) -> Optional[str]:
    """التحقق من استيفاء كلمة المرور للمعايير الأمنية القياسية"""
    if len(password) < 8:
        return "كلمة المرور يجب ألا تقل عن 8 خانات"
    if not re.search(r"[A-Z]", password):
        return "كلمة المرور يجب أن تحتوي على حرف كبير واحد على الأقل (A-Z)"
    if not re.search(r"[a-z]", password):
        return "كلمة المرور يجب أن تحتوي على حرف صغير واحد على الأقل (a-z)"
    if not re.search(r"[0-9]", password):
        return "كلمة المرور يجب أن تحتوي على رقم واحد على الأقل (0-9)"
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>\-_+=]", password):
        return "كلمة المرور يجب أن تحتوي على رمز خاص واحد على الأقل (!@#$%...)"
    return None


def create_auth_token(payload: dict) -> str:
    """إنشاء توكن جلسة موقع رقمياً بـ HMAC-SHA256 (بدون مكتبات خارجية)"""
    payload_copy = dict(payload)
    if "exp" not in payload_copy:
        payload_copy["exp"] = (datetime.now(timezone.utc) + timedelta(days=30)).timestamp()
    data_str = json.dumps(payload_copy, sort_keys=True)
    b64_data = base64.urlsafe_b64encode(data_str.encode("utf-8")).decode("utf-8").rstrip("=")
    sig = hmac.new(settings.SECRET_KEY.encode("utf-8"), b64_data.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{b64_data}.{sig}"


def decode_auth_token(token: str) -> Optional[dict]:
    """فك وتدقيق صحة توكن الجلسة والتحقق من التوقيع وتاريخ الصلاحية"""
    try:
        if not token or "." not in token:
            return None
        parts = token.strip().split(".")
        if len(parts) != 2:
            return None
        b64_data, sig = parts
        expected_sig = hmac.new(settings.SECRET_KEY.encode("utf-8"), b64_data.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected_sig):
            return None
        rem = len(b64_data) % 4
        padded = b64_data + ("=" * (4 - rem) if rem else "")
        raw = base64.urlsafe_b64decode(padded.encode("utf-8")).decode("utf-8")
        payload = json.loads(raw)
        if "exp" in payload and payload["exp"] < datetime.now(timezone.utc).timestamp():
            return None
        return payload
    except Exception:
        return None


def get_current_user(request: Request, db: Session) -> Optional[dict]:
    """استخراج بيانات المستخدم والصلاحيات من الهيدر الصريح أولاً ثم الكوكي"""
    token = request.headers.get("X-Na7la-Token")
    if not token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header[7:].strip()
    if not token:
        token = request.cookies.get("na7la_token")
    if not token:
        return None
    return decode_auth_token(token)


# ==============================================================================
# 1. إدارة البث اللحظي عبر الـ WebSockets
# ==============================================================================
class WSConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, list[WebSocket]] = {}

    async def connect(self, mac: str, websocket: WebSocket):
        await websocket.accept()
        mac = mac.upper()
        self.active_connections.setdefault(mac, []).append(websocket)

    def disconnect(self, mac: str, websocket: WebSocket):
        mac = mac.upper()
        if mac in self.active_connections and websocket in self.active_connections[mac]:
            self.active_connections[mac].remove(websocket)

    async def broadcast_to_mac(self, mac: str, message: dict):
        mac = mac.upper()
        for connection in list(self.active_connections.get(mac, [])):
            try:
                await connection.send_json(message)
            except Exception:
                self.disconnect(mac, connection)


ws_manager = WSConnectionManager()
na7la_hub.ws_broadcaster = ws_manager.broadcast_to_mac


# ==============================================================================
# 2. محرك الجدولة والمؤقتات السحابية بالأنماط الأربعة (Background Scheduler)
# ==============================================================================
async def scheduler_loop():
    """فحص وتنفيذ المؤقتات والجداول الزمنية والتشغيل الدوري كل ثانية"""
    while True:
        db = SessionLocal()
        try:
            now = utc_now()
            due_schedules = (
                db.query(Schedule)
                .filter(Schedule.is_active == True, Schedule.next_run_at != None, Schedule.next_run_at <= now)
                .all()
            )
            for sched in due_schedules:
                sock = sched.socket
                if not sock or not sock.strip:
                    continue
                strip = sock.strip

                # تنفيذ الأمر على الهاردوير
                session = na7la_hub.get_session(strip.mac_address)
                if session:
                    asyncio.create_task(session.set_outlets([sock.socket_index], sched.target_state))

                sock.desired_state = sched.target_state
                log_event(
                    db, strip.id, sock.socket_index,
                    "ON" if sched.target_state else "OFF",
                    "SCHEDULE",
                    f"تنفيذ جدولة تلقائية ({sched.schedule_type})"
                )

                # تحديث دورة الجدولة
                if sched.schedule_type == "TIMER":
                    sched.is_active = False
                    sched.next_run_at = None
                elif sched.schedule_type == "AUTO_OFF":
                    # إبقاء الإطفاء التلقائي مفعلاً ليعمل في كل مرة يتم تشغيل المخرج مستقبلاً
                    sched.next_run_at = None
                elif sched.schedule_type == "CYCLE":
                    sched.target_state = not sched.target_state
                    delay = sched.cycle_on_sec if sched.target_state else sched.cycle_off_sec
                    sched.next_run_at = now + timedelta(seconds=delay or 60)
                elif sched.schedule_type == "CRON":
                    sched.next_run_at = sched.next_run_at + timedelta(days=1)

            if due_schedules:
                db.commit()
        except Exception as err:
            print(f"[{settings.PROJECT_NAME} Scheduler] خطأ: {err!r}")
        finally:
            db.close()

        await asyncio.sleep(1.0)


# ==============================================================================
# 3. دورة حياة السيرفر (Lifespan & Graceful Shutdown)
# ==============================================================================
def ensure_db_migrations():
    Base.metadata.create_all(bind=engine)
    try:
        from sqlalchemy import text
        with engine.connect() as conn:
            res = conn.execute(text("PRAGMA table_info(shared_access)")).fetchall()
            cols = [r[1] for r in res]
            if cols:
                if "member_name" not in cols:
                    conn.execute(text("ALTER TABLE shared_access ADD COLUMN member_name VARCHAR(100) DEFAULT 'فرد عائلة'"))
                if "allowed_sockets" not in cols:
                    conn.execute(text("ALTER TABLE shared_access ADD COLUMN allowed_sockets VARCHAR(50) DEFAULT '1,2,3,4'"))
                if "expires_at" not in cols:
                    conn.execute(text("ALTER TABLE shared_access ADD COLUMN expires_at DATETIME"))
                conn.commit()

            res_strips = conn.execute(text("PRAGMA table_info(strips)")).fetchall()
            strip_cols = [r[1] for r in res_strips]
            if strip_cols:
                if "icon" not in strip_cols:
                    conn.execute(text("ALTER TABLE strips ADD COLUMN icon VARCHAR(20) DEFAULT '💻'"))
                if "room_category" not in strip_cols:
                    conn.execute(text("ALTER TABLE strips ADD COLUMN room_category VARCHAR(50) DEFAULT 'office'"))
                conn.commit()
    except Exception as e:
        print(f"[Na7la DB Migration] Info: {e}")

ensure_db_migrations()


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_db_migrations()

    tcp_server = await asyncio.start_server(
        na7la_hub.handle_client, "0.0.0.0", settings.TCP_DEVICE_PORT
    )
    poll_task = asyncio.create_task(na7la_hub.poll_loop())
    sched_task = asyncio.create_task(scheduler_loop())

    print(f"[{settings.PROJECT_NAME} v{settings.VERSION}] running successfully!")
    print(f"🔌 Power Strip TCP Hub listening on port `{settings.TCP_DEVICE_PORT}`.")
    print(f"🌐 Web Dashboard ready on http://localhost:8000")

    yield

    print(f"[{settings.PROJECT_NAME}] Safely shutting down...")
    na7la_hub.flush_energy_cache_to_db()
    poll_task.cancel()
    sched_task.cancel()
    tcp_server.close()
    await tcp_server.wait_closed()


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Na7la IoT Global Platform for Smart Power Strips & Home Automation",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==============================================================================
# 4. نماذج الطلبات (Pydantic Schemas)
# ==============================================================================
class UserBootstrapReq(BaseModel):
    email: str
    full_name: str
    password: Optional[str] = None
    currency: Optional[str] = "EGP"
    electricity_rate_egp: Optional[float] = 1.45


class SwitchCommandReq(BaseModel):
    action: str = Field(..., description="on | off | toggle")


class ProtectionUpdateReq(BaseModel):
    strip_name: Optional[str] = None
    min_voltage: Optional[float] = None
    max_voltage: Optional[float] = None
    voltage_protect_enabled: Optional[bool] = None
    auto_shedding_enabled: Optional[bool] = None
    max_temp_c: Optional[int] = None
    max_total_watt: Optional[float] = None
    max_total_amp: Optional[float] = None
    child_lock: Optional[bool] = None


class SocketConfigReq(BaseModel):
    name: Optional[str] = None
    icon: Optional[str] = None
    is_favorite: Optional[bool] = None
    is_router: Optional[bool] = None
    power_on_behavior: Optional[str] = None
    max_watt_limit: Optional[float] = None
    min_watt_cutoff: Optional[float] = None
    cutoff_delay_sec: Optional[int] = None
    compressor_protect: Optional[bool] = None
    compressor_delay_sec: Optional[int] = None
    master_socket_id: Optional[int] = None
    master_trigger_watt: Optional[float] = None


class ScheduleCreateReq(BaseModel):
    schedule_type: str = "TIMER"  # CRON / TIMER / CYCLE / AUTO_OFF
    cron_expr: Optional[str] = None
    duration_sec: Optional[int] = None
    cycle_on_sec: Optional[int] = None
    cycle_off_sec: Optional[int] = None
    auto_off_delay_sec: Optional[int] = None
    target_state: bool = True


class SceneCreateReq(BaseModel):
    user_id: int
    scene_name: str
    icon: str = "sparkles"
    stagger_delay_ms: int = 1500
    actions: list[dict]


class AdminSetupReq(BaseModel):
    full_name: Optional[str] = None
    name: Optional[str] = None
    email: str
    password: str
    pin_code: Optional[str] = None
    pin: Optional[str] = None

    def get_full_name(self) -> str:
        return (self.full_name or self.name or "").strip()

    def get_pin(self) -> str:
        return (self.pin_code or self.pin or "1234").strip()


class RegisterReq(BaseModel):
    email: str
    password: str
    full_name: str
    pin_code: Optional[str] = None
    pin: Optional[str] = None

    def get_full_name(self) -> str:
        return (self.full_name or "").strip()

    def get_pin(self) -> str:
        return (self.pin_code or self.pin or "1234").strip()


class GoogleAuthReq(BaseModel):
    credential: str
    client_id: Optional[str] = None


class LoginReq(BaseModel):
    email: str
    password: str


class InviteLoginReq(BaseModel):
    invite_code: str


class VerifyPinReq(BaseModel):
    pin_code: Optional[str] = None
    pin: Optional[str] = None

    def get_pin(self) -> str:
        return (self.pin_code or self.pin or "").strip()


class ShareCreateReq(BaseModel):
    name: str
    permission_level: str = "FULL"  # FULL / PARTIAL / VIEW
    allowed_sockets: List[int] = Field(default_factory=lambda: [1, 2, 3, 4])
    duration_hours: Optional[int] = 0
    email: Optional[str] = None


class ServerMigrationReq(BaseModel):
    target_host: str
    target_port: int = 10086


class ClaimStripReq(BaseModel):
    strip_name: str
    icon: Optional[str] = "💻"
    room_category: Optional[str] = "office"
    sockets: Optional[List[dict]] = None


class UpdateStripReq(BaseModel):
    strip_name: Optional[str] = None
    icon: Optional[str] = None
    room_category: Optional[str] = None


class ProvisionApReq(BaseModel):
    ssid: str
    password: str
    ap_ip: Optional[str] = "192.168.1.1"
    ap_port: Optional[int] = 30300


# ==============================================================================
# 5. الصفحة الرئيسية المدمجة (Web Dashboard)
# ==============================================================================
@app.get("/", response_class=HTMLResponse, tags=["Dashboard"])
def get_dashboard():
    """عرض لوحة التحكم المدمجة ثنائية اللغة المتصلة بالسيرفر"""
    dashboard_path = Path(__file__).parent / "dashboard.html"
    if dashboard_path.exists():
        response = HTMLResponse(content=dashboard_path.read_text(encoding="utf-8"))
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response
    return HTMLResponse(content="<h1>Dashboard loading...</h1>")


# ==============================================================================
# 6. مسارات المشتركات والمخارج والتحكم الذكي
# ==============================================================================
@app.get("/api/v1/strips", tags=["Strips & Control"])
def list_strips(request: Request, user_id: Optional[int] = None, db: Session = Depends(get_db)):
    auth = get_current_user(request, db)
    query = db.query(Strip)

    if auth:
        if auth.get("role") != "ADMIN":
            uid = auth.get("user_id")
            shared_strip_ids = [
                s.strip_id for s in db.query(SharedAccess).filter(
                    SharedAccess.shared_with_user_id == uid,
                    SharedAccess.is_active == True
                ).all()
            ]
            query = query.filter((Strip.owner_id == uid) | (Strip.id.in_(shared_strip_ids)))
    elif user_id is not None:
        query = query.filter(Strip.owner_id == user_id)
    else:
        admin_exists = db.query(User).filter(User.role == "ADMIN").first()
        if admin_exists:
            query = query.filter(Strip.id == -1)
        else:
            query = query.filter(Strip.owner_id == None)

    strips = query.all()

    result = []
    for st in strips:
        rate = st.owner.electricity_rate_egp if (st.owner and st.owner.electricity_rate_egp) else 1.45
        sockets_data = []
        total_w = 0.0
        total_a = 0.0
        total_kwh = 0.0

        for s in sorted(st.sockets, key=lambda x: x.socket_index):
            net_kwh = round(max(0.0, s.raw_energy_kwh - s.energy_baseline_kwh), 3)
            total_w += s.current_watt
            total_a += s.current_amp
            total_kwh += net_kwh
            sockets_data.append({
                "id": s.id,
                "index": s.socket_index,
                "name": s.name,
                "icon": s.icon,
                "is_router": s.is_router,
                "is_favorite": s.is_favorite,
                "on": s.reported_state,
                "desired_on": s.desired_state,
                "power_on_behavior": s.power_on_behavior,
                "watt": s.current_watt,
                "amp": s.current_amp,
                "temp_c": s.current_temp_c,
                "kwh": net_kwh,
                "cost_egp": round(net_kwh * rate, 2),
                "max_watt_limit": s.max_watt_limit,
                "min_watt_cutoff": s.min_watt_cutoff,
                "cutoff_delay_sec": s.cutoff_delay_sec,
                "compressor_protect": s.compressor_protect,
                "compressor_delay_sec": s.compressor_delay_sec,
                "master_socket_id": s.master_socket_id,
                "master_trigger_watt": s.master_trigger_watt,
            })

        result.append({
            "id": st.id,
            "mac": st.mac_address,
            "name": st.strip_name,
            "icon": getattr(st, "icon", None) or "💻",
            "room_category": getattr(st, "room_category", None) or "office",
            "is_claimed": st.owner_id is not None,
            "owner_id": st.owner_id,
            "model": st.model,
            "fw": st.fw_version,
            "ip": st.ip_address,
            "online": st.is_online,
            "voltage": st.current_voltage,
            "rssi": st.wifi_rssi,
            "child_lock": st.child_lock,
            "total_watt": round(total_w, 2),
            "total_amp": round(total_a, 3),
            "total_kwh": round(total_kwh, 3),
            "total_cost_egp": round(total_kwh * rate, 2),
            "protection": {
                "min_voltage": st.min_voltage,
                "max_voltage": st.max_voltage,
                "voltage_protect_enabled": st.voltage_protect_enabled,
                "auto_shedding_enabled": st.auto_shedding_enabled,
                "max_temp_c": st.max_temp_c,
                "max_total_watt": st.max_total_watt,
                "max_total_amp": st.max_total_amp,
            },
            "sockets": sockets_data,
        })
    return {"system": settings.PROJECT_NAME, "strips": result}


@app.get("/api/v1/strips/unclaimed", tags=["Strips & Control"])
def list_unclaimed_strips(db: Session = Depends(get_db)):
    """استعراض المشتركات المكتشفة على الشبكة التي لم يتم ربطها بعد"""
    strips = db.query(Strip).filter(Strip.owner_id == None).all()
    result = []
    for st in strips:
        result.append({
            "id": st.id,
            "mac": st.mac_address,
            "name": st.strip_name,
            "model": st.model,
            "fw": st.fw_version,
            "ip": st.ip_address,
            "online": st.is_online,
            "voltage": st.current_voltage,
            "rssi": st.wifi_rssi,
        })
    return {"unclaimed": result}


@app.post("/api/v1/strips/{mac}/claim", tags=["Strips & Control"])
def claim_strip(mac: str, req: ClaimStripReq, request: Request, db: Session = Depends(get_db)):
    """ربط وتخصيص المشترك المكتشف ونسب ملكيته لحساب المستخدم"""
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير مسجل في السيرفر بعد")

    auth = get_current_user(request, db)
    if not auth:
        raise HTTPException(status_code=401, detail="يرجى تسجيل الدخول أولاً لربط المشترك بحسابك")

    user_id = auth.get("user_id")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="المستخدم غير موجود")

    # حماية ملكية المشترك
    if strip.owner_id is not None and strip.owner_id != user.id and user.role != "ADMIN":
        raise HTTPException(status_code=403, detail="هذا المشترك مرتبط ومملوك بالفعل لحساب مستخدم آخر")

    # التحقق من كوتا الأجهزة المسموحة
    if user.role != "ADMIN" and strip.owner_id != user.id:
        owned_count = db.query(Strip).filter(Strip.owner_id == user.id).count()
        limit = user.max_strips or getattr(settings, "DEFAULT_USER_MAX_STRIPS", 1)
        if owned_count >= limit:
            raise HTTPException(
                status_code=403,
                detail=f"لقد وصلت للحد الأقصى المسموح به لحسابك ({limit} مشترك). يرجى التواصل مع الإدارة لزيادة السعة."
            )

    strip.owner_id = user.id
    if req.strip_name:
        strip.strip_name = req.strip_name.strip()
    if req.icon:
        strip.icon = req.icon.strip()
    if req.room_category:
        strip.room_category = req.room_category.strip()

    if req.sockets:
        for s_info in req.sockets:
            idx = s_info.get("index")
            sock = db.query(Socket).filter(Socket.strip_id == strip.id, Socket.socket_index == idx).first()
            if sock:
                if "name" in s_info and s_info["name"]:
                    sock.name = s_info["name"].strip()
                if "is_router" in s_info:
                    sock.is_router = bool(s_info["is_router"])

    db.commit()
    actor = auth.get("name") if auth else "ADMIN"
    log_event(db, strip.id, 0, "STRIP_CLAIM", actor, f"تم ربط المشترك '{strip.strip_name}' وتخصيص الغرفة '{strip.room_category}'")
    return {
        "ok": True,
        "strip": {
            "mac": strip.mac_address,
            "name": strip.strip_name,
            "icon": strip.icon,
            "room_category": strip.room_category
        }
    }


@app.post("/api/v1/strips/provision-ap", tags=["Strips & Control"])
async def provision_strip_ap(req: ProvisionApReq):
    """إرسال بيانات واي فاي الراوتر إلى المشترك في وضع الـ SoftAP عبر 192.168.1.1:30300"""
    ssid = req.ssid.strip()
    password = req.password.strip()
    ap_ip = req.ap_ip or "192.168.1.1"
    ap_port = req.ap_port or 30300

    if not ssid:
        raise HTTPException(status_code=400, detail="اسم شبكة الواي فاي مطلوب")

    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ap_ip, ap_port), timeout=4.0
        )
        payload = f"set:wifi:{ssid}:{password}\r\n".encode("utf-8")
        writer.write(payload)
        await writer.drain()
        await asyncio.sleep(0.5)
        writer.close()
        await writer.wait_closed()
        return {"ok": True, "message": "تم إرسال بيانات الواي فاي للمشترك بنجاح، سيعيد التشغيل ويتصل بالشبكة"}
    except Exception:
        raise HTTPException(
            status_code=400,
            detail=f"تعذر الاتصال بنقطة وصول المشترك ({ap_ip}:{ap_port}). تأكد من أنك متصل بشبكة واي فاي المشترك (TONLY_TAP_...) أولاً."
        )


@app.patch("/api/v1/strips/{mac}", tags=["Strips & Control"])
def update_strip_metadata(mac: str, req: UpdateStripReq, request: Request, db: Session = Depends(get_db)):
    """تعديل اسم المشترك أو أيقونته أو تصنيف الغرفة"""
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    admin = db.query(User).filter(User.role == "ADMIN").first()
    if admin:
        auth = get_current_user(request, db)
        if not auth or auth.get("role") != "ADMIN":
            raise HTTPException(status_code=403, detail="تعديل بيانات المشترك متاح للمدير فقط")

    if req.strip_name is not None:
        strip.strip_name = req.strip_name.strip()
    if req.icon is not None:
        strip.icon = req.icon.strip()
    if req.room_category is not None:
        strip.room_category = req.room_category.strip()

    db.commit()
    return {"ok": True, "name": strip.strip_name, "icon": strip.icon, "room_category": strip.room_category}


@app.delete("/api/v1/strips/{mac}", tags=["Strips & Control"])
def unpair_strip(mac: str, request: Request, db: Session = Depends(get_db)):
    """فك ربط المشترك من الحساب"""
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    admin = db.query(User).filter(User.role == "ADMIN").first()
    if admin:
        auth = get_current_user(request, db)
        if not auth or auth.get("role") != "ADMIN":
            raise HTTPException(status_code=403, detail="فك ربط المشترك متاح للمدير فقط")

    strip.owner_id = None
    db.commit()
    log_event(db, strip.id, 0, "STRIP_UNPAIR", "ADMIN", f"تم فك ربط المشترك '{strip.strip_name}' ({mac}) من الحساب")
    return {"ok": True, "message": "تم فك ربط المشترك بنجاح"}


@app.post("/api/v1/strips/{mac}/sockets/{socket_index}/switch", tags=["Strips & Control"])
async def switch_socket(
    mac: str,
    socket_index: int,
    req: SwitchCommandReq,
    request: Request = None,
    db: Session = Depends(get_db)
):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير مسجل")

    actor = "USER"
    admin_exists = db.query(User).filter(User.role == "ADMIN").first()
    if admin_exists and request:
        auth = get_current_user(request, db)
        if not auth:
            raise HTTPException(status_code=401, detail="يرجى تسجيل الدخول أو إدخال كود الدعوة")
        role = auth.get("role", "MEMBER")
        level = auth.get("level", "FULL")
        allowed = auth.get("allowed_sockets", [1, 2, 3, 4])
        actor = f"{auth.get('name', 'User')} ({role})"

        if role != "ADMIN":
            if level == "VIEW":
                raise HTTPException(status_code=403, detail="صلاحيتك للمشاهدة فقط ولا يمكنك التبديل")
            if socket_index == 0:
                raise HTTPException(status_code=403, detail="غير مصرح لك باستخدام زر الإطفاء الشامل")
            if socket_index not in allowed:
                raise HTTPException(status_code=403, detail=f"غير مصرح لك بالتحكم في المخرج رقم {socket_index}")

    session = na7la_hub.get_session(strip.mac_address)

    # التحكم الشامل (Master Switch: socket_index == 0) مع حماية الراوتر
    if socket_index == 0:
        act = req.action.lower()
        if act == "off":
            # إطفاء كافة الفيش باستثناء فيشة الراوتر
            targets = [s for s in strip.sockets if not s.is_router]
            for s in targets:
                s.desired_state = False
            log_event(db, strip.id, 0, "OFF", actor, "إطفاء شامل (مع استثناء فيشة الراوتر المحمية)")
            db.commit()

            if session:
                target_chs = [s.socket_index for s in targets]
                if target_chs:
                    await session.set_outlets(target_chs, False, stagger_sec=0.15)
            return {"ok": True, "detail": "تم إطفاء المخارج مع الحفاظ على الراوتر"}
        else:
            # تشغيل الكل مع تتابع زمني لمنع شرارة البدء
            for s in strip.sockets:
                s.desired_state = True
            log_event(db, strip.id, 0, "ON", actor, "تشغيل شامل لكافة المخارج مع تتابع زمني")
            db.commit()

            if session:
                await session.set_outlets([1, 2, 3, 4], True, stagger_sec=0.8)
            return {"ok": True, "detail": "تم تشغيل كافة المخارج"}

    # التحكم في مقبس فردي (1 إلى 4)
    sock = db.query(Socket).filter(Socket.strip_id == strip.id, Socket.socket_index == socket_index).first()
    if not sock:
        raise HTTPException(status_code=404, detail="رقم المقبس غير صحيح")

    act = req.action.lower().strip()
    target_state = not sock.reported_state if act == "toggle" else (act in ("on", "true", "1"))

    # حماية مواتير التبريد (Compressor Guard)
    if target_state and sock.compressor_protect and sock.last_off_timestamp:
        elapsed = (utc_now() - sock.last_off_timestamp.replace(tzinfo=timezone.utc)).total_seconds()
        safe_delay = sock.compressor_delay_sec or 180
        if elapsed < safe_delay:
            rem = int(safe_delay - elapsed)
            raise HTTPException(
                status_code=409,
                detail=f"حماية الموتور مفعلة: يرجى الانتظار {rem} ثانية قبل إعادة تشغيل هذا المقبس"
            )

    sock.desired_state = target_state
    if not target_state:
        sock.last_off_timestamp = utc_now()
        auto_scheds = db.query(Schedule).filter(Schedule.socket_id == sock.id, Schedule.schedule_type == "AUTO_OFF").all()
        for asc in auto_scheds:
            asc.next_run_at = None
    else:
        # إذا كان للمخرج جدولة إطفاء تلقائي مفعلة
        auto_scheds = db.query(Schedule).filter(Schedule.socket_id == sock.id, Schedule.schedule_type == "AUTO_OFF", Schedule.is_active == True).all()
        for asc in auto_scheds:
            asc.next_run_at = utc_now() + timedelta(seconds=asc.auto_off_delay_sec or 600)
            asc.target_state = False

    log_event(db, strip.id, sock.socket_index, "ON" if target_state else "OFF", actor, "أمر مباشر من لوحة التحكم")
    db.commit()

    confirmed = False
    if session:
        confirmed = await session.set_outlets([sock.socket_index], target_state)

    return {"ok": True, "confirmed": confirmed, "desired_state": sock.desired_state}


@app.patch("/api/v1/strips/{mac}/protection", tags=["Protection & Settings"])
async def update_strip_protection(mac: str, req: ProtectionUpdateReq, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    # [DISABLED FOR STOCK 1.0.66] تعطيل إرسال أمر قفل الأطفال للمشترك لتجنب الارتداد العنيف
    # if req.child_lock is not None and req.child_lock != strip.child_lock:
    #     session = na7la_hub.get_session(strip.mac_address)
    #     if session:
    #         await session.set_child_lock(req.child_lock)
    #     strip.child_lock = req.child_lock
    #     log_event(
    #         db, strip.id, 0, "CHILD_LOCK_TOGGLE", "USER",
    #         f"تم {'تفعيل' if req.child_lock else 'إلغاء'} قفل الأطفال على مستوى عتاد المشترك (Hardware)"
    #     )

    for field, val in req.model_dump(exclude_unset=True).items():
        setattr(strip, field, val)
    db.commit()

    await na7la_hub.broadcast_update(strip.mac_address, {
        "event": "protection_update",
        "mac": strip.mac_address,
        "child_lock": strip.child_lock,
    })

    return {"ok": True, "message": "تم تحديث إعدادات الحماية وقفل الأطفال بنجاح", "child_lock": strip.child_lock}


@app.patch("/api/v1/strips/{mac}/sockets/{socket_index}/config", tags=["Protection & Settings"])
def update_socket_config(mac: str, socket_index: int, req: SocketConfigReq, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")
    sock = db.query(Socket).filter(Socket.strip_id == strip.id, Socket.socket_index == socket_index).first()
    if not sock:
        raise HTTPException(status_code=404, detail="المقبس غير موجود")

    for field, val in req.model_dump(exclude_unset=True).items():
        setattr(sock, field, val)
    db.commit()
    return {
        "ok": True,
        "socket_index": socket_index,
        "name": sock.name,
        "is_router": sock.is_router,
        "master_socket_id": sock.master_socket_id,
        "master_trigger_watt": sock.master_trigger_watt,
    }


@app.post("/api/v1/strips/{mac}/sockets/{socket_index}/reset-energy", tags=["Analytics & Energy"])
def reset_socket_energy(mac: str, socket_index: int, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")
    sock = db.query(Socket).filter(Socket.strip_id == strip.id, Socket.socket_index == socket_index).first()
    if not sock:
        raise HTTPException(status_code=404, detail="المقبس غير موجود")

    sock.energy_baseline_kwh = sock.raw_energy_kwh
    log_event(db, strip.id, socket_index, "ENERGY_RESET", "USER", f"تصفير عداد الطاقة عند القراءة {sock.raw_energy_kwh} kWh")
    db.commit()
    return {"ok": True, "new_baseline_kwh": sock.energy_baseline_kwh}


# ==============================================================================
# 7. مسارات الجداول والمؤقتات الذكية (Schedules & Timers API)
# ==============================================================================
@app.get("/api/v1/strips/{mac}/sockets/{socket_index}/schedules", tags=["Schedules & Automations"])
def list_socket_schedules(mac: str, socket_index: int, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")
    sock = db.query(Socket).filter(Socket.strip_id == strip.id, Socket.socket_index == socket_index).first()
    if not sock:
        raise HTTPException(status_code=404, detail="المقبس غير موجود")

    schedules = db.query(Schedule).filter(Schedule.socket_id == sock.id).order_by(Schedule.created_at.desc()).all()
    return {
        "mac": mac,
        "socket_index": socket_index,
        "socket_name": sock.name,
        "schedules": [
            {
                "id": sc.id,
                "schedule_type": sc.schedule_type,
                "cron_expr": sc.cron_expr,
                "duration_sec": sc.duration_sec,
                "cycle_on_sec": sc.cycle_on_sec,
                "cycle_off_sec": sc.cycle_off_sec,
                "auto_off_delay_sec": sc.auto_off_delay_sec,
                "target_state": sc.target_state,
                "is_active": sc.is_active,
                "next_run_at": sc.next_run_at.isoformat() if sc.next_run_at else None,
                "created_at": sc.created_at.isoformat() if sc.created_at else None,
            }
            for sc in schedules
        ],
    }


@app.post("/api/v1/strips/{mac}/sockets/{socket_index}/schedules", tags=["Schedules & Automations"])
def create_socket_schedule(mac: str, socket_index: int, req: ScheduleCreateReq, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")
    sock = db.query(Socket).filter(Socket.strip_id == strip.id, Socket.socket_index == socket_index).first()
    if not sock:
        raise HTTPException(status_code=404, detail="المقبس غير موجود")

    sched_type = req.schedule_type.upper().strip()
    now = utc_now()
    next_run = None

    if sched_type == "TIMER":
        dur = req.duration_sec or 60
        next_run = now + timedelta(seconds=dur)
    elif sched_type == "CYCLE":
        delay = req.cycle_on_sec if req.target_state else req.cycle_off_sec
        next_run = now + timedelta(seconds=delay or 60)
    elif sched_type == "AUTO_OFF":
        next_run = (now + timedelta(seconds=req.auto_off_delay_sec or 600)) if sock.reported_state else None
    elif sched_type == "CRON":
        next_run = now + timedelta(days=1)

    sched = Schedule(
        socket_id=sock.id,
        schedule_type=sched_type,
        cron_expr=req.cron_expr,
        duration_sec=req.duration_sec,
        cycle_on_sec=req.cycle_on_sec,
        cycle_off_sec=req.cycle_off_sec,
        auto_off_delay_sec=req.auto_off_delay_sec,
        target_state=req.target_state,
        is_active=True,
        next_run_at=next_run,
    )
    db.add(sched)
    db.commit()
    db.refresh(sched)

    log_event(
        db, strip.id, socket_index, "SCHEDULE_CREATE", "USER",
        f"إنشاء جدولة جديدة ({sched_type}) للمخرج '{sock.name}'"
    )

    return {
        "ok": True,
        "schedule": {
            "id": sched.id,
            "schedule_type": sched.schedule_type,
            "target_state": sched.target_state,
            "is_active": sched.is_active,
            "next_run_at": sched.next_run_at.isoformat() if sched.next_run_at else None,
        },
    }


@app.delete("/api/v1/schedules/{schedule_id}", tags=["Schedules & Automations"])
def delete_schedule(schedule_id: int, db: Session = Depends(get_db)):
    sched = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not sched:
        raise HTTPException(status_code=404, detail="الجدولة غير موجودة")
    db.delete(sched)
    db.commit()
    return {"ok": True, "message": "تم حذف الجدولة بنجاح"}


@app.patch("/api/v1/schedules/{schedule_id}/toggle", tags=["Schedules & Automations"])
def toggle_schedule(schedule_id: int, db: Session = Depends(get_db)):
    sched = db.query(Schedule).filter(Schedule.id == schedule_id).first()
    if not sched:
        raise HTTPException(status_code=404, detail="الجدولة غير موجودة")
    sched.is_active = not sched.is_active
    if sched.is_active and sched.schedule_type == "TIMER":
        sched.next_run_at = utc_now() + timedelta(seconds=sched.duration_sec or 60)
    db.commit()
    return {"ok": True, "is_active": sched.is_active}


# ==============================================================================
# 8. تصدير سجلات الطاقة إلى Excel (.csv)
# ==============================================================================
@app.get("/api/v1/strips/{mac}/export-energy", tags=["Analytics & Energy"])
def export_energy_csv(mac: str, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    socket_ids = [s.id for s in strip.sockets]
    logs = (
        db.query(EnergyLog)
        .filter(EnergyLog.socket_id.in_(socket_ids))
        .order_by(EnergyLog.period_start.desc())
        .limit(1000)
        .all()
    )

    socks_map = {s.id: s for s in strip.sockets}
    output = io.StringIO()
    # كتابة رأس ملف الإكسل
    output.write("Timestamp,Socket Index,Socket Name,Period,Average Watts,Max Watts,Delta kWh,Est Cost EGP\n")

    for l in logs:
        s = socks_map.get(l.socket_id)
        s_idx = s.socket_index if s else 0
        s_name = s.name if s else "Outlet"
        ts = l.period_start.strftime("%Y-%m-%d %H:%M:%S") if l.period_start else ""
        output.write(f'"{ts}",{s_idx},"{s_name}",{l.period_type},{l.watt_avg},{l.watt_max},{l.kwh_delta},{l.estimated_cost_egp}\n')

    content = output.getvalue()
    return Response(
        content=content,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=na7la_energy_{mac}.csv"},
    )


# ==============================================================================
# 8. البوابة المزدوجة لـ Samsung Modes & Routines (بروابط IP ديناميكية)
# ==============================================================================
@app.get("/api/v1/android/shortcuts-manifest", tags=["Samsung Routines"])
def get_android_shortcuts_manifest(request: Request, user_id: Optional[int] = None, db: Session = Depends(get_db)):
    base_url = settings.SERVER_PUBLIC_URL.strip() or str(request.base_url).rstrip('/')

    query = db.query(Strip)
    if user_id:
        query = query.filter((Strip.owner_id == user_id) | (Strip.owner_id == None))
    strips = query.all()

    shortcuts = []
    user = db.query(User).filter(User.id == user_id).first() if user_id else None
    token = user.webhook_token if (user and user.webhook_token) else "local_token"

    for st in strips:
        for s in sorted(st.sockets, key=lambda x: x.socket_index):
            for act, label_ar in [("on", "تشغيل"), ("off", "إيقاف"), ("toggle", "عكس حالة")]:
                shortcuts.append({
                    "shortcut_id": f"na7la_{st.mac_address}_{s.socket_index}_{act}",
                    "short_label": f"{label_ar} {s.name}",
                    "long_label": f"{label_ar} {s.name} ({st.strip_name})",
                    "intent_uri": f"na7laiot://routine/switch?mac={st.mac_address}&socket={s.socket_index}&action={act}",
                    "cloud_webhook_url": f"{base_url}/api/v1/webhook/{token}/trigger?mac={st.mac_address}&socket={s.socket_index}&action={act}",
                })

    return {
        "system": settings.PROJECT_NAME,
        "base_url_used": base_url,
        "total_shortcuts": len(shortcuts),
        "shortcuts": shortcuts,
    }


@app.api_route("/api/v1/webhook/{webhook_token}/trigger", methods=["GET", "POST"], tags=["Samsung Routines"])
async def trigger_routine_webhook(
    webhook_token: str,
    mac: str = Query(...),
    socket: int = Query(...),
    action: str = Query("toggle"),
    db: Session = Depends(get_db),
):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    req = SwitchCommandReq(action=action)
    return await switch_socket(mac, socket, req, db)


# ==============================================================================
# 9. سجل الأحداث وقناة البث اللحظي (Audit Logs & WebSocket)
# ==============================================================================
@app.get("/api/v1/strips/{mac}/logs", tags=["Analytics & Energy"])
def get_strip_audit_logs(mac: str, limit: int = 20, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")
    logs = (
        db.query(AuditLog)
        .filter(AuditLog.strip_id == strip.id)
        .order_by(AuditLog.timestamp.desc())
        .limit(limit)
        .all()
    )
    return {
        "mac": strip.mac_address,
        "logs": [
            {
                "id": l.id,
                "socket": l.socket_index,
                "action": l.action,
                "triggered_by": l.triggered_by,
                "reason": l.reason_details,
                "timestamp": l.timestamp.isoformat() if l.timestamp else "",
            }
            for l in logs
        ],
    }


@app.websocket("/ws/strips/{mac}")
async def websocket_strip_endpoint(websocket: WebSocket, mac: str):
    await ws_manager.connect(mac, websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(mac, websocket)


# ==============================================================================
# 10. نظام المصادقة وإدارة المستخدمين (Authentication & Admin Setup)
# ==============================================================================
@app.get("/api/v1/auth/status", tags=["Authentication & Access"])
def get_auth_status(request: Request, db: Session = Depends(get_db)):
    admin = db.query(User).filter(User.role == "ADMIN").first()
    has_admin = admin is not None
    auth = get_current_user(request, db)

    if not has_admin:
        return {
            "authenticated": False,
            "has_admin": False,
            "admin_exists": False,
            "needs_setup": True,
            "user": None,
            "role": None,
            "name": None,
            "google_client_id": settings.GOOGLE_CLIENT_ID or "",
            "permissions": {"level": "ADMIN", "allowed_sockets": [1, 2, 3, 4], "is_admin": True}
        }

    if not auth:
        return {
            "authenticated": False,
            "has_admin": True,
            "admin_exists": True,
            "needs_setup": False,
            "user": None,
            "role": None,
            "name": None,
            "google_client_id": settings.GOOGLE_CLIENT_ID or "",
            "permissions": {"level": "NONE", "allowed_sockets": [], "is_admin": False}
        }

    return {
        "authenticated": True,
        "has_admin": True,
        "admin_exists": True,
        "needs_setup": False,
        "role": auth.get("role"),
        "name": auth.get("name"),
        "level": auth.get("level", "FULL"),
        "allowed_sockets": auth.get("allowed_sockets", [1, 2, 3, 4]),
        "google_client_id": settings.GOOGLE_CLIENT_ID or "",
        "user": {
            "id": auth.get("user_id"),
            "name": auth.get("name"),
            "email": auth.get("email"),
            "role": auth.get("role"),
        },
        "permissions": {
            "level": auth.get("level", "FULL"),
            "allowed_sockets": auth.get("allowed_sockets", [1, 2, 3, 4]),
            "is_admin": auth.get("role") == "ADMIN",
        }
    }


@app.post("/api/v1/auth/setup-admin", tags=["Authentication & Access"])
def setup_admin_account(req: AdminSetupReq, response: Response, db: Session = Depends(get_db)):
    admin_exists = db.query(User).filter(User.role == "ADMIN").first()
    if admin_exists:
        raise HTTPException(status_code=400, detail="حساب المدير مسجل بالفعل")

    policy_err = validate_password_strength(req.password)
    if policy_err:
        raise HTTPException(status_code=422, detail=policy_err)

    hashed_pw = hash_password(req.password)
    hashed_pin = hash_password(req.get_pin())

    name = req.get_full_name() or "Admin"
    admin = User(
        email=req.email.strip().lower(),
        password_hash=hashed_pw,
        full_name=name,
        role="ADMIN",
        pin_code_hash=hashed_pin
    )
    db.add(admin)
    db.commit()
    db.refresh(admin)

    # ربط كافة المشتركات غير المربوطة بحساب المدير الجديد
    db.query(Strip).filter(Strip.owner_id == None).update({"owner_id": admin.id})
    db.commit()

    token = create_auth_token({
        "user_id": admin.id,
        "name": admin.full_name,
        "email": admin.email,
        "role": "ADMIN",
        "level": "ADMIN",
        "allowed_sockets": [1, 2, 3, 4]
    })

    response.set_cookie("na7la_token", token, max_age=86400 * 30, httponly=True, samesite="lax")
    return {
        "ok": True,
        "token": token,
        "role": "ADMIN",
        "name": admin.full_name,
        "allowed_sockets": [1, 2, 3, 4],
        "user": {
            "id": admin.id,
            "name": admin.full_name,
            "email": admin.email,
            "role": "ADMIN"
        },
        "permissions": {
            "level": "ADMIN",
            "allowed_sockets": [1, 2, 3, 4],
            "is_admin": True
        }
    }


@app.post("/api/v1/auth/register", tags=["Authentication & Access"])
def register_new_user(req: RegisterReq, response: Response, db: Session = Depends(get_db)):
    email_clean = req.email.strip().lower()
    if not email_clean or "@" not in email_clean:
        raise HTTPException(status_code=422, detail="يرجى إدخال بريد إلكتروني صالح")

    existing = db.query(User).filter(User.email == email_clean).first()
    if existing:
        raise HTTPException(status_code=400, detail="البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول")

    policy_err = validate_password_strength(req.password)
    if policy_err:
        raise HTTPException(status_code=422, detail=policy_err)

    hashed_pw = hash_password(req.password)
    hashed_pin = hash_password(req.get_pin())

    admin_emails = [e.lower() for e in getattr(settings, "ADMIN_EMAILS", [])]
    is_admin_email = email_clean in admin_emails
    admin_exists = db.query(User).filter(User.role == "ADMIN").first()
    is_admin = is_admin_email or (not admin_exists)
    role = "ADMIN" if is_admin else "USER"
    max_strips = 999 if is_admin else getattr(settings, "DEFAULT_USER_MAX_STRIPS", 1)
    name = req.get_full_name() or ("Admin" if role == "ADMIN" else "User")

    new_user = User(
        email=email_clean,
        password_hash=hashed_pw,
        full_name=name,
        role=role,
        max_strips=max_strips,
        pin_code_hash=hashed_pin
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    if role == "ADMIN" and not admin_exists:
        db.query(Strip).filter(Strip.owner_id == None).update({"owner_id": new_user.id})
        db.commit()

    level = "ADMIN" if role == "ADMIN" else "FULL"
    allowed_socks = [1, 2, 3, 4]

    token = create_auth_token({
        "user_id": new_user.id,
        "name": new_user.full_name or new_user.email,
        "email": new_user.email,
        "role": new_user.role,
        "level": level,
        "allowed_sockets": allowed_socks
    })

    response.set_cookie("na7la_token", token, max_age=86400 * 30, httponly=True, samesite="lax")
    return {
        "ok": True,
        "token": token,
        "role": new_user.role,
        "name": new_user.full_name or new_user.email,
        "allowed_sockets": allowed_socks,
        "user": {
            "id": new_user.id,
            "name": new_user.full_name or new_user.email,
            "email": new_user.email,
            "role": new_user.role
        },
        "permissions": {
            "level": level,
            "allowed_sockets": allowed_socks,
            "is_admin": role == "ADMIN"
        }
    }


@app.post("/api/v1/auth/google", tags=["Authentication & Access"])
def login_or_register_with_google(req: GoogleAuthReq, response: Response, db: Session = Depends(get_db)):
    credential = req.credential.strip()
    if not credential:
        raise HTTPException(status_code=400, detail="رمز التحقق من Google مطلوب")

    google_email = None
    google_sub = None
    google_name = None

    # 1. دعم وضع الاختبار المحلي السريع والمحاكاة
    if credential.startswith("simulated:") or credential.startswith("test:"):
        parts = credential.split(":")
        google_email = parts[1].strip().lower() if len(parts) > 1 else "google_user@na7la.com"
        google_name = parts[2].strip() if len(parts) > 2 else "Google User"
        google_sub = f"g_sim_{hashlib.md5(google_email.encode()).hexdigest()[:16]}"
    else:
        # 2. التحقق الرسمي عبر google-auth
        try:
            from google.oauth2 import id_token
            from google.auth.transport import requests as google_requests

            client_id = req.client_id or settings.GOOGLE_CLIENT_ID or None
            idinfo = id_token.verify_oauth2_token(
                credential,
                google_requests.Request(),
                client_id
            )
            google_sub = idinfo.get("sub")
            google_email = (idinfo.get("email") or "").strip().lower()
            google_name = idinfo.get("name") or idinfo.get("given_name") or "Google User"
        except Exception as e:
            raise HTTPException(status_code=401, detail=f"فشل التحقق من هوية Google: {str(e)}")

    if not google_email or not google_sub:
        raise HTTPException(status_code=400, detail="تعذر استخراج بيانات الحساب من Google")

    admin_emails = [e.lower() for e in getattr(settings, "ADMIN_EMAILS", [])]
    is_admin_email = google_email in admin_emails

    # البحث عن المستخدم بالـ google_uid أولاً أو بالبريد
    user = db.query(User).filter(User.google_uid == google_sub).first()
    if not user:
        user = db.query(User).filter(User.email == google_email).first()
        if user:
            user.google_uid = google_sub
            if not user.full_name and google_name:
                user.full_name = google_name
            if is_admin_email and user.role != "ADMIN":
                user.role = "ADMIN"
                user.max_strips = 999
            db.commit()
            db.refresh(user)
    elif is_admin_email and user.role != "ADMIN":
        user.role = "ADMIN"
        user.max_strips = 999
        db.commit()
        db.refresh(user)

    if not user:
        admin_exists = db.query(User).filter(User.role == "ADMIN").first()
        is_admin = is_admin_email or (not admin_exists)
        role = "ADMIN" if is_admin else "USER"
        max_strips = 999 if is_admin else getattr(settings, "DEFAULT_USER_MAX_STRIPS", 1)
        user = User(
            email=google_email,
            google_uid=google_sub,
            full_name=google_name,
            role=role,
            max_strips=max_strips
        )
        db.add(user)
        db.commit()
        db.refresh(user)

        if role == "ADMIN" and not admin_exists:
            db.query(Strip).filter(Strip.owner_id == None).update({"owner_id": user.id})
            db.commit()

    level = "ADMIN" if user.role == "ADMIN" else "FULL"
    allowed_socks = [1, 2, 3, 4]
    if user.role != "ADMIN":
        share = db.query(SharedAccess).filter(SharedAccess.shared_with_user_id == user.id, SharedAccess.is_active == True).first()
        if share:
            level = share.permission_level
            allowed_socks = [int(x) for x in (share.allowed_sockets or "1,2,3,4").split(",") if x.isdigit()]

    token = create_auth_token({
        "user_id": user.id,
        "name": user.full_name or user.email,
        "email": user.email,
        "role": user.role,
        "level": level,
        "allowed_sockets": allowed_socks
    })

    response.set_cookie("na7la_token", token, max_age=86400 * 30, httponly=True, samesite="lax")
    return {
        "ok": True,
        "token": token,
        "role": user.role,
        "name": user.full_name or user.email,
        "allowed_sockets": allowed_socks,
        "user": {
            "id": user.id,
            "name": user.full_name or user.email,
            "email": user.email,
            "role": user.role
        },
        "permissions": {
            "level": level,
            "allowed_sockets": allowed_socks,
            "is_admin": user.role == "ADMIN"
        }
    }


@app.post("/api/v1/auth/login", tags=["Authentication & Access"])
def login_with_email(req: LoginReq, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email.strip().lower()).first()
    if not user or not user.password_hash or not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="البريد الإلكتروني أو كلمة المرور غير صحيحة")

    level = "ADMIN" if user.role == "ADMIN" else "FULL"
    allowed_socks = [1, 2, 3, 4]
    if user.role != "ADMIN":
        share = db.query(SharedAccess).filter(SharedAccess.shared_with_user_id == user.id, SharedAccess.is_active == True).first()
        if share:
            level = share.permission_level
            allowed_socks = [int(x) for x in (share.allowed_sockets or "1,2,3,4").split(",") if x.isdigit()]

    token = create_auth_token({
        "user_id": user.id,
        "name": user.full_name or user.email,
        "email": user.email,
        "role": user.role,
        "level": level,
        "allowed_sockets": allowed_socks
    })

    response.set_cookie("na7la_token", token, max_age=86400 * 30, httponly=True, samesite="lax")
    return {
        "ok": True,
        "token": token,
        "role": user.role,
        "name": user.full_name or user.email,
        "allowed_sockets": allowed_socks,
        "user": {
            "id": user.id,
            "name": user.full_name or user.email,
            "email": user.email,
            "role": user.role
        },
        "permissions": {
            "level": level,
            "allowed_sockets": allowed_socks,
            "is_admin": user.role == "ADMIN"
        }
    }


@app.post("/api/v1/auth/login-invite", tags=["Authentication & Access"])
def login_with_invite_code(req: InviteLoginReq, response: Response, db: Session = Depends(get_db)):
    code = req.invite_code.strip().upper()
    share = db.query(SharedAccess).filter(SharedAccess.invite_code == code, SharedAccess.is_active == True).first()
    if not share:
        raise HTTPException(status_code=404, detail="كود الدعوة غير صحيح أو تم إلغاؤه")

    now = utc_now()
    if share.expires_at and share.expires_at.replace(tzinfo=timezone.utc) < now:
        raise HTTPException(status_code=410, detail="عذراً، انتهت صلاحية كود الدعوة هذا")

    allowed_socks = [int(x) for x in (share.allowed_sockets or "1,2,3,4").split(",") if x.isdigit()]

    token = create_auth_token({
        "user_id": share.shared_with_user_id,
        "share_id": share.id,
        "name": share.member_name,
        "email": None,
        "role": "MEMBER",
        "level": share.permission_level,
        "allowed_sockets": allowed_socks,
        "exp": share.expires_at.timestamp() if share.expires_at else (datetime.now(timezone.utc) + timedelta(days=365)).timestamp()
    })

    response.set_cookie("na7la_token", token, max_age=86400 * 30, httponly=True, samesite="lax")
    return {
        "ok": True,
        "token": token,
        "role": "MEMBER",
        "name": share.member_name,
        "allowed_sockets": allowed_socks,
        "user": {
            "id": share.shared_with_user_id,
            "name": share.member_name,
            "role": "MEMBER"
        },
        "permissions": {
            "level": share.permission_level,
            "allowed_sockets": allowed_socks,
            "is_admin": False
        }
    }


@app.post("/api/v1/auth/verify-pin", tags=["Authentication & Access"])
def verify_admin_pin(req: VerifyPinReq, db: Session = Depends(get_db)):
    admin = db.query(User).filter(User.role == "ADMIN").first()
    if not admin:
        return {"ok": True, "valid": True}
    pin = req.get_pin()
    if not admin.pin_code_hash:
        return {"ok": True, "valid": pin == "1234"}
    valid = verify_password(pin, admin.pin_code_hash)
    if not valid:
        raise HTTPException(status_code=401, detail="رمز الـ PIN غير صحيح")
    return {"ok": True, "valid": True}


@app.post("/api/v1/auth/logout", tags=["Authentication & Access"])
def logout_user(response: Response):
    response.delete_cookie("na7la_token")
    return {"ok": True, "message": "تم تسجيل الخروج بنجاح"}


# ==============================================================================
# 11. نظام المشاركة العائلية (Family Sharing & Hybrid Access)
# ==============================================================================
@app.get("/api/v1/strips/{mac}/shares", tags=["Family Sharing"])
def list_strip_shares(mac: str, request: Request, db: Session = Depends(get_db)):
    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    shares = db.query(SharedAccess).filter(SharedAccess.strip_id == strip.id).order_by(SharedAccess.created_at.desc()).all()
    now = utc_now()
    return {
        "shares": [
            {
                "id": sh.id,
                "name": sh.member_name,
                "permission_level": sh.permission_level,
                "allowed_sockets": [int(x) for x in (sh.allowed_sockets or "1,2,3,4").split(",") if x.isdigit()],
                "invite_code": sh.invite_code,
                "is_active": sh.is_active,
                "is_expired": bool(sh.expires_at and sh.expires_at.replace(tzinfo=timezone.utc) < now),
                "expires_at": sh.expires_at.isoformat() if sh.expires_at else None,
                "created_at": sh.created_at.isoformat() if sh.created_at else None,
            }
            for sh in shares
        ]
    }


@app.post("/api/v1/strips/{mac}/shares", tags=["Family Sharing"])
def create_strip_share(mac: str, req: ShareCreateReq, request: Request, db: Session = Depends(get_db)):
    admin = db.query(User).filter(User.role == "ADMIN").first()
    if admin:
        auth = get_current_user(request, db)
        if not auth or auth.get("role") != "ADMIN":
            raise HTTPException(status_code=403, detail="إنشاء ومشاركة الصلاحيات مخصصة لمدير النظام فقط")

    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    # توليد كود دعوة فريد ومختصر
    code = f"NA7LA-{secrets.token_hex(2).upper()}"
    while db.query(SharedAccess).filter(SharedAccess.invite_code == code).first():
        code = f"NA7LA-{secrets.token_hex(2).upper()}"

    # حساب تاريخ انتهاء الصلاحية
    exp = (utc_now() + timedelta(hours=req.duration_hours)) if req.duration_hours and req.duration_hours > 0 else None

    name = req.name.strip()
    email = req.email.strip().lower() if req.email else f"member_{secrets.token_hex(3)}@na7la.local"
    member_user = db.query(User).filter(User.email == email).first()
    if not member_user:
        member_user = User(
            email=email,
            full_name=name,
            role="USER"
        )
        db.add(member_user)
        db.commit()
        db.refresh(member_user)

    socks_str = ",".join(str(x) for x in req.allowed_sockets) if req.allowed_sockets else "1,2,3,4"

    share = SharedAccess(
        strip_id=strip.id,
        shared_with_user_id=member_user.id,
        member_name=name,
        permission_level=req.permission_level.upper(),
        allowed_sockets=socks_str,
        invite_code=code,
        expires_at=exp,
        is_active=True
    )
    db.add(share)
    db.commit()
    db.refresh(share)

    log_event(db, strip.id, 0, "SHARE_CREATE", "ADMIN", f"إنشاء كود دعوة جديد '{code}' لـ '{name}' (الصلاحية: {req.permission_level})")

    return {
        "ok": True,
        "share": {
            "id": share.id,
            "name": share.member_name,
            "permission_level": share.permission_level,
            "allowed_sockets": req.allowed_sockets,
            "invite_code": share.invite_code,
            "expires_at": share.expires_at.isoformat() if share.expires_at else None,
        }
    }


@app.delete("/api/v1/shares/{share_id}", tags=["Family Sharing"])
def delete_strip_share(share_id: int, request: Request, db: Session = Depends(get_db)):
    admin = db.query(User).filter(User.role == "ADMIN").first()
    if admin:
        auth = get_current_user(request, db)
        if not auth or auth.get("role") != "ADMIN":
            raise HTTPException(status_code=403, detail="إلغاء المشاركة مخصص لمدير النظام فقط")

    share = db.query(SharedAccess).filter(SharedAccess.id == share_id).first()
    if not share:
        raise HTTPException(status_code=404, detail="كود المشاركة غير موجود")
    strip_id = share.strip_id
    code = share.invite_code
    db.delete(share)
    db.commit()
    log_event(db, strip_id, 0, "SHARE_REVOKE", "ADMIN", f"إلغاء وحذف كود الدعوة '{code}'")
    return {"ok": True}


@app.patch("/api/v1/shares/{share_id}/toggle", tags=["Family Sharing"])
def toggle_strip_share(share_id: int, request: Request, db: Session = Depends(get_db)):
    admin = db.query(User).filter(User.role == "ADMIN").first()
    if admin:
        auth = get_current_user(request, db)
        if not auth or auth.get("role") != "ADMIN":
            raise HTTPException(status_code=403, detail="تعديل المشاركة مخصص لمدير النظام فقط")

    share = db.query(SharedAccess).filter(SharedAccess.id == share_id).first()
    if not share:
        raise HTTPException(status_code=404, detail="كود المشاركة غير موجود")
    share.is_active = not share.is_active
    db.commit()
    return {"ok": True, "is_active": share.is_active}


# ==============================================================================
# 12. التحويل السحابي ونقل المشترك (Cloud Migration)
# ==============================================================================
@app.post("/api/v1/strips/{mac}/migrate-server", tags=["Cloud Migration"])
async def migrate_strip_server(
    mac: str,
    req: ServerMigrationReq,
    request: Request,
    db: Session = Depends(get_db)
):
    admin = db.query(User).filter(User.role == "ADMIN").first()
    if admin:
        auth = get_current_user(request, db)
        if not auth or auth.get("role") != "ADMIN":
            raise HTTPException(status_code=403, detail="هذه العملية مخصصة لمدير النظام فقط")

    target_host = req.target_host.strip()
    target_port = req.target_port or 10086

    strip = db.query(Strip).filter(Strip.mac_address == mac.upper()).first()
    if not strip:
        raise HTTPException(status_code=404, detail="المشترك غير موجود")

    session = na7la_hub.get_session(strip.mac_address)
    if not session:
        raise HTTPException(status_code=400, detail="المشترك غير متصل حالياً بالسيرفر المحلي")

    # فحص أمان مسبق (Pre-flight check) للتأكد من وصول السيرفر الهدف
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(target_host, target_port), timeout=3.5
        )
        writer.close()
        await writer.wait_closed()
    except Exception:
        raise HTTPException(
            status_code=400,
            detail=f"تعذر الاتصال بالسيرفر السحابي ({target_host}:{target_port}). تأكد من تشغيل السيرفر وفتح البورت أولاً لمنع المشترك من فقدان الاتصال."
        )

    # إرسال أمر التوجيه للمشترك عبر جلسة الـ TCP الحالية
    cmd = f"up:connect:{target_host}:{target_port}\r\n".encode("utf-8")
    session.writer.write(cmd)
    await session.writer.drain()

    log_event(db, strip.id, 0, "SERVER_MIGRATE", "ADMIN", f"توجيه المشترك إلى السيرفر السحابي ({target_host}:{target_port})")

    return {
        "ok": True,
        "message": f"تم إرسال أمر التوجيه بنجاح. المشترك يتصل الآن بالسيرفر السحابي ({target_host}:{target_port})."
    }


# ==============================================================================
# 9. إدارة المستخدمين والكوتا للأدمن (Admin User & Quota Management)
# ==============================================================================
class UpdateQuotaReq(BaseModel):
    max_strips: int = Field(..., ge=1, le=1000)


@app.get("/api/v1/admin/users", tags=["Admin & User Management"])
def admin_list_users(request: Request, db: Session = Depends(get_db)):
    auth = get_current_user(request, db)
    if not auth or auth.get("role") != "ADMIN":
        raise HTTPException(status_code=403, detail="هذه الواجهة مخصصة لمدير النظام فقط")

    users = db.query(User).order_by(User.id.asc()).all()
    out = []
    for u in users:
        strips_count = db.query(Strip).filter(Strip.owner_id == u.id).count()
        out.append({
            "id": u.id,
            "email": u.email,
            "full_name": u.full_name or "مستخدم",
            "role": u.role,
            "google_uid": u.google_uid,
            "is_google_user": bool(u.google_uid),
            "max_strips": u.max_strips or 1,
            "strips_count": strips_count,
            "created_at": u.created_at.isoformat() if u.created_at else None,
        })
    return {"users": out}


@app.patch("/api/v1/admin/users/{user_id}/quota", tags=["Admin & User Management"])
def admin_update_user_quota(user_id: int, req: UpdateQuotaReq, request: Request, db: Session = Depends(get_db)):
    auth = get_current_user(request, db)
    if not auth or auth.get("role") != "ADMIN":
        raise HTTPException(status_code=403, detail="هذه العملية مخصصة لمدير النظام فقط")

    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="المستخدم غير موجود")

    target_user.max_strips = req.max_strips
    db.commit()
    return {
        "ok": True,
        "user_id": target_user.id,
        "email": target_user.email,
        "max_strips": target_user.max_strips,
        "message": f"تم تحديث كوتا المستخدم '{target_user.email}' إلى {target_user.max_strips} مشترك بنجاح."
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)