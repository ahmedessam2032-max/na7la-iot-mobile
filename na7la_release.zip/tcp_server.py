import asyncio
import json
import re
import socket
import uuid
from datetime import datetime, timezone
from typing import Callable, Coroutine, Any, Optional

from config import settings
from database import SessionLocal
from models import Strip, Socket, AuditLog, EnergyLog
from plugins import PROTECTION_AND_AUTOMATION_RULES, log_event

# التعبيرات النمطية لبروتوكول المشترك (Stock 0.1.54-1.0.66)
BOOTINFO_RE = re.compile(
    r"^up:bootinfo:([^;\r\n]+);([0-9A-Fa-f]{12});([0-9A-Fa-f]{12});([^;\r\n]+);connect$"
)
GETINFO_RE = re.compile(
    r"(?P<ch>[1-5]):(?P<runtime>-?\d+);(?P<relay>on|off);(?P<state>-?\d+);"
    r"(?P<overload>[^;:]+);(?P<overheat>[^;:]+);(?P<power>-?\d+);"
    r"(?P<energy>[0-9A-Fa-f]{8});(?P<previous>[0-9A-Fa-f]{8});"
    r"(?P<config>[0-9A-Fa-f]{8});(?P<status>[^;:]+);"
    r"(?P<event>[0-9A-Fa-f]{2});(?P<temperature>-?\d+)",
    re.I,
)
ONOFF_ACK_RE = re.compile(r"^up:onoff:([1-4]):(on|off)$", re.I)
EVENT_RE = re.compile(r"^up:event:onoff:([0-4]):(on|off)$", re.I)
POWER_REPORT_RE = re.compile(r"^up:power_report:([1-5]):(-?\d+)$", re.I)
QUERY_RE = re.compile(r"^up:query:(-?\d+)$")
CHILDLOCK_ACK_RE = re.compile(r"^up:(?:childlock|cl):(?:ok|state|set):(?:mask:)?(\d{1,2})$", re.I)
CHILDLOCK_STATE_RE = re.compile(r"^up:(?:childlock|cl):(?:mask:)?(\d{1,2})$", re.I)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def calibrate_current(raw_amps: float, power_w: float = 0.0) -> float:
    """معايرة تيار المخرج بأسلوب العتبة الذكية (Deadband Threshold) لمنع تشويه قراءات الأحمال الصغيرة"""
    if raw_amps <= 0.0 or power_w < 0.3:
        return 0.0
    # إذا كان هناك سحب واط حقيقي للجهاز (>= 0.8W)، يتم اعتماد التيار الفيزيائي الحقيقي بدون خصم جائر
    if power_w >= 0.8:
        return round(raw_amps, 3)
    # في منطقة الشوشرة الحثية الصرفة (أقل من 0.8W)، يتم طرح إزاحة شوشرة الحساس
    return round(max(0.0, raw_amps - settings.CURRENT_NOISE_OFFSET_AMP), 3)


def parse_getinfo(line: str) -> list[dict]:
    """فك تشفير تقرير الحالة والحساسات (up:getinfo) مع إلغاء الفلاج المضلل"""
    text = line.strip("\r\n\x00 ")
    if text.startswith("up:getinfo:"):
        text = text[len("up:getinfo:"):]
    out = []
    for m in GETINFO_RE.finditer(text):
        g = m.groupdict()
        ch = int(g["ch"])
        if ch > 4:
            continue
        out.append({
            "n": ch,
            "on": g["relay"].lower() == "on",
            "runtime_sec": max(0, int(g["runtime"])),
            # تم تحويل الفلاج النصي لـ False لمنع أي فصل كاذب من الفيرموير القديم
            "overload": False,
            "overheat": False,
            "power_w": round(max(0, int(g["power"])) / 1000.0, 2),
            "energy_kwh": round(int(g["energy"], 16) / 1000.0, 3),
            "temp_c": int(g["temperature"]),  # سيليزيوس حقيقي مباشرة
        })
    return out


class StripSession:
    """جلسة اتصال TCP آمنة لمشترك واحد مع قفل التزامن (Mutex Lock)"""

    def __init__(self, ip: str, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.session_uuid = str(uuid.uuid4())
        self.ip = ip
        self.reader = reader
        self.writer = writer
        self.lock = asyncio.Lock()
        self.got_getinfo = asyncio.Event()

        self.mac: Optional[str] = None
        self.strip_id: Optional[int] = None
        self.last_cmd = ""
        self.last_rx = ""

        # عدادات الحماية والتأكيد المزدوج
        self.consecutive_voltage_faults = 0
        self.voltage_recovery_streak = 0
        self.voltage_tripped = False

        # تحسين زمن الاستجابة على مستوى السوكت
        sock = writer.get_extra_info("socket")
        if sock is not None:
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass

    async def send_raw(self, cmd: str) -> None:
        self.last_cmd = cmd
        self.writer.write((cmd + "\r\n").encode("ascii"))
        await self.writer.drain()

    async def _refresh_unlocked(self, timeout: float = 3.5) -> bool:
        self.got_getinfo.clear()
        await self.send_raw("up:getinfo:all")
        try:
            await asyncio.wait_for(self.got_getinfo.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def refresh(self, timeout: float = 3.5) -> bool:
        async with self.lock:
            return await self._refresh_unlocked(timeout)

    async def set_outlets(self, channels: list[int], on: bool, stagger_sec: float = settings.STAGGER_DEFAULT_SEC) -> bool:
        """تشغيل أو إطفاء المقابس بتتابع زمني لمنع شرارة البدء وتيار الإقلاع"""
        async with self.lock:
            for idx, ch in enumerate(channels):
                await self.send_raw(f"up:onoff:{ch}:{'on' if on else 'off'}")
                if idx < len(channels) - 1 and stagger_sec > 0:
                    await asyncio.sleep(stagger_sec)
            await asyncio.sleep(settings.RELAY_SETTLE_DELAY_SEC)
            return await self._refresh_unlocked()

    async def query_diagnostics(self) -> None:
        """طلب قراءة الفولت وإشارة الواي فاي"""
        async with self.lock:
            await self.send_raw("up:power_report:1:vol")
            await asyncio.sleep(0.1)
            await self.send_raw("up:query:wifirssi")

    async def set_child_lock(self, enabled: bool) -> bool:
        """[معطل لفيرموير 1.0.66] تفعيل أو تعطيل قفل الأطفال على مستوى عتاد المشترك (Hardware MCU)"""
        # [DISABLED FOR STOCK 1.0.66: Firmware 1.0.66 does not support up:childlock]
        # mask = 31 if enabled else 0
        # async with self.lock:
        #     await self.send_raw(f"up:childlock:{mask}")
        #     await asyncio.sleep(0.1)
        #     await self.send_raw("up:childlock")
        return True


class Na7laTCPHub:
    """النواة المركزية لمنصة Na7la IoT لإدارة المشتركات وربطها بالشبكة"""

    def __init__(self) -> None:
        self.sessions: dict[str, StripSession] = {}
        self.ws_broadcaster: Optional[Callable[[str, dict], Coroutine[Any, Any, None]]] = None
        self.hourly_energy_cache: dict[int, dict[str, float]] = {}

    def get_session(self, mac: str) -> Optional[StripSession]:
        s = self.sessions.get(mac.upper())
        if s and not s.writer.is_closing():
            return s
        return None

    async def broadcast_update(self, mac: str, payload: dict) -> None:
        if self.ws_broadcaster:
            try:
                await self.ws_broadcaster(mac.upper(), payload)
            except Exception:
                pass

    async def process_telemetry(self, session: StripSession, records: list[dict]) -> None:
        """معالجة قراءات الواط والأمبير والحرارة وفحص قواعد الحماية الذكية"""
        if not session.mac:
            return
        db = SessionLocal()
        try:
            strip = db.query(Strip).filter(Strip.mac_address == session.mac).first()
            if not strip:
                return

            sockets_map = {s.socket_index: s for s in strip.sockets}
            total_watt = 0.0
            total_amp = 0.0
            voltage = strip.current_voltage or 220.0

            for r in records:
                sock = sockets_map.get(r["n"])
                if not sock:
                    continue

                if sock.reported_state and not r["on"]:
                    sock.last_off_timestamp = utc_now()

                # [DISABLED FOR STOCK 1.0.66] حارس قفل الأطفال (Child Lock Software Watchdog)
                # تم تعطيله لمنع ارتداد الريليه (Relay Bounce) وانقطاع الطاقة عن الأجهزة الحساسة (الكمبيوتر والراوتر)
                # if strip.child_lock and sock.desired_state and not r["on"]:
                #     asyncio.create_task(session.set_outlets([sock.socket_index], True))
                #     log_event(
                #         db, strip.id, sock.socket_index, "CHILD_LOCK_GUARD", "WATCHDOG",
                #         f"إحباط محاولة فصل المقبس {sock.socket_index} ({sock.name}) فيزيائياً وإعادة تشغيله فوراً"
                #     )
                #     asyncio.create_task(self.broadcast_update(strip.mac_address, {
                #         "event": "child_lock_tamper",
                #         "mac": strip.mac_address,
                #         "socket_index": sock.socket_index,
                #         "socket_name": sock.name,
                #         "message": f"تنبيه أمان: تم إحباط فصل المخرج رقم {sock.socket_index} ({sock.name}) فيزيائياً أثناء تفعيل قفل الأطفال وإعادة تشغيله فوراً."
                #     }))
                #     r["on"] = True

                sock.reported_state = r["on"]
                sock.desired_state = r["on"]
                sock.current_watt = r["power_w"]
                sock.current_temp_c = r["temp_c"]
                sock.runtime_seconds = r["runtime_sec"]
                sock.hw_overload_flag = False
                sock.hw_overheat_flag = False

                raw_amp = (r["power_w"] / voltage) if (voltage > 0 and r["on"]) else 0.0
                sock.current_amp = calibrate_current(raw_amp, r["power_w"])

                # تصفير الآمان في حالة إعادة تعيين الفيرموير للعداد
                if r["energy_kwh"] < sock.raw_energy_kwh:
                    sock.energy_baseline_kwh = 0.0
                sock.raw_energy_kwh = r["energy_kwh"]

                total_watt += sock.current_watt
                total_amp += sock.current_amp

                # تحديث كاش الاستهلاك التراكمي
                cache = self.hourly_energy_cache.setdefault(
                    sock.id, {
                        "watt_sum": 0.0, "count": 0, "watt_max": 0.0,
                        "start_kwh": r["energy_kwh"], "last_kwh": r["energy_kwh"]
                    }
                )
                cache["watt_sum"] += sock.current_watt
                cache["count"] += 1
                cache["watt_max"] = max(cache["watt_max"], sock.current_watt)
                cache["last_kwh"] = r["energy_kwh"]

            # تشغيل محرك القواعد والحماية التلقائية
            for rule_func in PROTECTION_AND_AUTOMATION_RULES:
                tripped_all = await rule_func(session, db, strip, sockets_map, total_watt, total_amp)
                if tripped_all:
                    break

            strip.last_seen = utc_now()
            db.commit()

            # بث التحديث اللحظي لجميع المتصفحات المتصلة بالـ WebSocket
            rate = strip.owner.electricity_rate_egp if (strip.owner and strip.owner.electricity_rate_egp) else 1.45
            total_kwh = sum(round(max(0.0, s.raw_energy_kwh - s.energy_baseline_kwh), 3) for s in strip.sockets)
            await self.broadcast_update(strip.mac_address, {
                "system": settings.PROJECT_NAME,
                "event": "telemetry_update",
                "mac": strip.mac_address,
                "name": strip.strip_name,
                "model": strip.model,
                "fw": strip.fw_version,
                "ip": strip.ip_address,
                "online": strip.is_online,
                "voltage": strip.current_voltage,
                "rssi": strip.wifi_rssi,
                "child_lock": strip.child_lock,
                "total_watt": round(total_watt, 2),
                "total_amp": round(total_amp, 3),
                "total_kwh": round(total_kwh, 3),
                "total_cost_egp": round(total_kwh * rate, 2),
                "sockets": [
                    {
                        "id": s.id,
                        "index": s.socket_index,
                        "name": s.name,
                        "icon": s.icon,
                        "is_router": s.is_router,
                        "is_favorite": s.is_favorite,
                        "on": s.reported_state,
                        "watt": s.current_watt,
                        "amp": s.current_amp,
                        "temp_c": s.current_temp_c,
                        "master_socket_id": s.master_socket_id,
                        "master_trigger_watt": s.master_trigger_watt,
                        "kwh": round(max(0.0, s.raw_energy_kwh - s.energy_baseline_kwh), 3),
                        "cost_egp": round(max(0.0, s.raw_energy_kwh - s.energy_baseline_kwh) * rate, 2),
                    }
                    for s in sorted(strip.sockets, key=lambda x: x.socket_index)
                ],
            })
        finally:
            db.close()

    async def evaluate_voltage(self, session: StripSession, voltage_v: float) -> None:
        """مراقبة الجهد اللحظي واستعادة الفيش تلقائياً بعد استقرار الكهرباء"""
        if not session.mac:
            return
        db = SessionLocal()
        try:
            strip = db.query(Strip).filter(Strip.mac_address == session.mac).first()
            if not strip:
                return

            strip.current_voltage = voltage_v

            # إذا كانت حماية الجهد مفعلة من قِبل المستخدم
            if strip.voltage_protect_enabled:
                min_v = strip.min_voltage or 185.0
                max_v = strip.max_voltage or 245.0

                # فحص تذبذب الفولت خارج الرينج
                if voltage_v < min_v or voltage_v > max_v:
                    session.consecutive_voltage_faults += 1
                    session.voltage_recovery_streak = 0

                    if session.consecutive_voltage_faults >= 2 and not session.voltage_tripped:
                        # حفظ الفيش التي كانت شغالة لاستعادتها لاحقاً
                        active_indices = [s.socket_index for s in strip.sockets if s.reported_state]
                        strip.pre_trip_state = json.dumps(active_indices)
                        session.voltage_tripped = True

                        # فصل الأربع مخارج طوارئ لحماية الأجهزة
                        asyncio.create_task(session.set_outlets([1, 2, 3, 4], False, stagger_sec=0.15))
                        log_event(
                            db, strip.id, 0, "VOLTAGE_TRIP", "PROTECTION",
                            f"فصل طوارئ لحماية الأجهزة: الجهد {voltage_v}V خارج النطاق الآمن ({min_v}V - {max_v}V)"
                        )
                        await self.broadcast_update(strip.mac_address, {
                            "event": "voltage_trip",
                            "voltage": voltage_v,
                            "message": f"تم فصل المخارج طوارئ بسبب تذبذب الجهد ({voltage_v}V)"
                        })
                else:
                    # الفولت مستقر وآمن
                    session.consecutive_voltage_faults = 0

                    if session.voltage_tripped and strip.auto_recover_voltage:
                        session.voltage_recovery_streak += 1

                        # التأكد من استقرار الفولت لـ 4 دورات استطلاع متتالية
                        if session.voltage_recovery_streak >= 4:
                            pre_sockets = []
                            try:
                                pre_sockets = json.loads(strip.pre_trip_state or "[]")
                            except Exception:
                                pre_sockets = [1, 2, 3, 4]

                            session.voltage_tripped = False
                            session.voltage_recovery_streak = 0

                            if pre_sockets:
                                # تشغيل الفيش التي كانت تعمل فقط بتتابع زمني
                                asyncio.create_task(session.set_outlets(pre_sockets, True, stagger_sec=0.8))
                                log_event(
                                    db, strip.id, 0, "VOLTAGE_RECOVER", "PROTECTION",
                                    f"استقرار الجهد عند {voltage_v}V واستعادة تشغيل الفيش: {pre_sockets}"
                                )
                                await self.broadcast_update(strip.mac_address, {
                                    "event": "voltage_recovered",
                                    "voltage": voltage_v,
                                    "message": "استقر الجهد وتمت استعادة تشغيل أجهزتك بنجاح"
                                })

            db.commit()
        finally:
            db.close()

    async def handle_physical_button(self, session: StripSession, ch: int, is_on: bool) -> None:
        """معالجة الضغط اليدوي على زر المشترك مع دعم قفل الأطفال الفوري"""
        if not session.mac:
            return
        db = SessionLocal()
        try:
            strip = db.query(Strip).filter(Strip.mac_address == session.mac).first()
            if not strip:
                return

            # [DISABLED FOR STOCK 1.0.66] حالة قفل الأطفال: إبطال الضغطة فوراً
            # تم تعطيله لمنع ارتداد الريليه (Relay Bounce) وانقطاع الطاقة عن الأجهزة الحساسة (الكمبيوتر والراوتر)
            # if strip.child_lock:
            #     channels = [1, 2, 3, 4] if ch == 0 else [ch]
            #     asyncio.create_task(session.set_outlets(channels, not is_on, stagger_sec=0.1))
            #     log_event(
            #         db, strip.id, ch, "CHILD_LOCK_REVERT", "PROTECTION",
            #         f"تم إبطال ضغطة الزر اليدوي للمخرج {ch} بواسطة قفل الأطفال"
            #     )
            #     db.commit()
            #     await self.broadcast_update(strip.mac_address, {
            #         "event": "child_lock_triggered",
            #         "socket": ch,
            #         "message": f"تنبيه: تم إبطال ضغطة يد لأطفال على مخرج {ch}"
            #     })
            #     return

            # الاستجابة العادية بدون قفل أطفال
            for sock in strip.sockets:
                if ch == 0 or sock.socket_index == ch:
                    sock.reported_state = is_on
                    sock.desired_state = is_on
                    # تصفير الواط والأمبير فورياً عند الإغلاق دون انتظار
                    if not is_on:
                        sock.current_watt = 0.0
                        sock.current_amp = 0.0

            log_event(db, strip.id, ch, "ON" if is_on else "OFF", "PHYSICAL_BUTTON", "تغيير يدوي من زر المشترك")
            db.commit()

            # إطلاق تحديث سريع للبيانات في الحال
            asyncio.create_task(session.refresh())
        finally:
            db.close()

    async def handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        """إدارة دورة حياة اتصال العميل والمشترك"""
        peer = writer.get_extra_info("peername")
        ip = peer[0] if peer else "?"
        session = StripSession(ip, reader, writer)
        print(f"[{settings.PROJECT_NAME} TCP] New connection from {ip}")

        try:
            while True:
                raw = await reader.readline()
                if not raw:
                    break
                if len(raw) > 8192:
                    raise ValueError("Line too long")

                line = raw.replace(b"\x00", b"").decode("utf-8", "replace").strip("\r\n ")
                session.last_rx = line

                # حزمة الإقلاع (Zero-Touch Boot)
                m = BOOTINFO_RE.match(line)
                if m:
                    model, mac, _, fw = m.group(1), m.group(2).upper(), m.group(3), m.group(4)
                    session.mac = mac

                    old = self.sessions.get(mac)
                    if old and old is not session:
                        old.writer.close()
                    self.sessions[mac] = session

                    db = SessionLocal()
                    try:
                        strip = db.query(Strip).filter(Strip.mac_address == mac).first()
                        if not strip:
                            strip = Strip(
                                mac_address=mac,
                                strip_name=f"Na7la Strip {mac[-4:]}",
                                model=model,
                                fw_version=fw,
                                ip_address=ip,
                                is_online=True,
                                last_seen=utc_now(),
                            )
                            db.add(strip)
                            db.flush()
                            # إنشاء المخارج الأربعة بأسماء محايدة
                            for i in range(1, 5):
                                db.add(Socket(
                                    strip_id=strip.id,
                                    socket_index=i,
                                    name=f"مقبس {i}",
                                    power_on_behavior="LAST",
                                ))
                        else:
                            strip.model, strip.fw_version, strip.ip_address = model, fw, ip
                            strip.is_online = True
                            strip.last_seen = utc_now()
                        db.commit()
                        session.strip_id = strip.id
                    finally:
                        db.close()

                    print(f"[{settings.PROJECT_NAME} TCP] ✅ Client {mac} securely connected (fw={fw})")
                    # قراءة حالة المشترك الحقيقية بدون لمس أي ريليه
                    asyncio.create_task(session.refresh())
                    asyncio.create_task(session.query_diagnostics())
                    # [DISABLED FOR STOCK 1.0.66] مزامنة قفل الأطفال في عتاد المشترك فور اتصاله
                    # db_check = SessionLocal()
                    # try:
                    #     st = db_check.query(Strip).filter(Strip.mac_address == mac).first()
                    #     if st and st.child_lock:
                    #         asyncio.create_task(session.set_child_lock(True))
                    # finally:
                    #     db_check.close()
                    continue

                if not session.mac:
                    continue

                if line.startswith("up:getinfo:"):
                    records = parse_getinfo(line)
                    if len(records) == 4:
                        session.got_getinfo.set()
                        await self.process_telemetry(session, records)
                    continue

                if line.lower().startswith("up:power_report:"):
                    m = POWER_REPORT_RE.fullmatch(line)
                    if m and int(m.group(2)) >= 50000:
                        await self.evaluate_voltage(session, round(int(m.group(2)) / 1000.0, 1))
                    continue

                m = QUERY_RE.fullmatch(line)
                if m:
                    db = SessionLocal()
                    try:
                        strip = db.query(Strip).filter(Strip.mac_address == session.mac).first()
                        if strip:
                            strip.wifi_rssi = int(m.group(1))
                            db.commit()
                    finally:
                        db.close()
                    continue

                m = EVENT_RE.fullmatch(line)
                if m:
                    await self.handle_physical_button(session, int(m.group(1)), m.group(2).lower() == "on")
                    continue

                m = CHILDLOCK_ACK_RE.fullmatch(line) or CHILDLOCK_STATE_RE.fullmatch(line)
                if m:
                    mask = int(m.group(1))
                    print(f"[{settings.PROJECT_NAME} TCP] 🔒 Child lock hardware state confirmed: mask={mask}")
                    continue

                m = ONOFF_ACK_RE.fullmatch(line)
                if m:
                    ch = int(m.group(1))
                    state = m.group(2).lower() == "on"
                    # [DISABLED FOR STOCK 1.0.66] حارس تأكيد التغيير (Watchdog on ONOFF_ACK)
                    # تم تعطيله لمنع ارتداد الريليه (Relay Bounce) وانقطاع الطاقة عن الأجهزة الحساسة (الكمبيوتر والراوتر)
                    # db_onoff = SessionLocal()
                    # try:
                    #     strip = db_onoff.query(Strip).filter(Strip.mac_address == session.mac).first()
                    #     if strip and strip.child_lock:
                    #         sock = next((s for s in strip.sockets if s.socket_index == ch), None)
                    #         if sock and sock.desired_state and not state:
                    #             asyncio.create_task(session.set_outlets([ch], True))
                    #             log_event(db_onoff, strip.id, ch, "CHILD_LOCK_GUARD", "WATCHDOG", f"إحباط محاولة فصل المقبس {ch} عبر إشارة up:onoff وإعادة تشغيله فوراً")
                    #             asyncio.create_task(self.broadcast_update(strip.mac_address, {
                    #                 "event": "child_lock_tamper",
                    #                 "mac": strip.mac_address,
                    #                 "socket_index": ch,
                    #                 "socket_name": sock.name,
                    #                 "message": f"تنبيه أمان: تم إحباط فصل المخرج {ch} ({sock.name}) أثناء تفعيل قفل الأطفال وإعادة تشغيله تلقائياً."
                    #             }))
                    # finally:
                    #     db_onoff.close()
                    continue

        except (ConnectionResetError, BrokenPipeError, asyncio.IncompleteReadError):
            pass
        except Exception as err:
            print(f"[{settings.PROJECT_NAME} TCP] خطأ جلسة {ip}: {err!r}")
        finally:
            if session.mac and self.sessions.get(session.mac) is session:
                self.sessions.pop(session.mac, None)
                db = SessionLocal()
                try:
                    strip = db.query(Strip).filter(Strip.mac_address == session.mac).first()
                    if strip:
                        strip.is_online = False
                        db.commit()
                finally:
                    db.close()
                print(f"[{settings.PROJECT_NAME} TCP] Client {session.mac} is offline")
                await self.broadcast_update(session.mac, {"event": "status_change", "mac": session.mac, "online": False})

            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

    def flush_energy_cache_to_db(self) -> None:
        """حفظ إحصائيات الطاقة التراكمية في قاعدة البيانات دورياً"""
        if not self.hourly_energy_cache:
            return
        db = SessionLocal()
        try:
            now = utc_now()
            for socket_id, data in list(self.hourly_energy_cache.items()):
                if data["count"] == 0:
                    continue
                sock = db.query(Socket).filter(Socket.id == socket_id).first()
                if not sock:
                    continue
                rate = sock.strip.owner.electricity_rate_egp if (sock.strip and sock.strip.owner and sock.strip.owner.electricity_rate_egp) else 1.45
                watt_avg = round(data["watt_sum"] / data["count"], 2)
                kwh_delta = round(max(0.0, data["last_kwh"] - data["start_kwh"]), 4)
                db.add(EnergyLog(
                    socket_id=socket_id,
                    period_start=now,
                    period_type="HOURLY",
                    watt_avg=watt_avg,
                    watt_max=data["watt_max"],
                    kwh_delta=kwh_delta,
                    estimated_cost_egp=round(kwh_delta * rate, 3),
                ))
                self.hourly_energy_cache[socket_id] = {
                    "watt_sum": 0.0, "count": 0, "watt_max": 0.0,
                    "start_kwh": data["last_kwh"], "last_kwh": data["last_kwh"]
                }
            db.commit()
        finally:
            db.close()

    async def poll_loop(self) -> None:
        """حلقة الاستطلاع الدورية الرئيسية كل 5 ثوانٍ"""
        cycle = 0
        while True:
            cycle += 1
            for session in list(self.sessions.values()):
                if not session.mac:
                    continue
                try:
                    if await session.refresh() and cycle % settings.DIAG_EVERY_N_POLLS == 0:
                        await session.query_diagnostics()
                except Exception:
                    pass
            if cycle % 180 == 0:
                self.flush_energy_cache_to_db()
            await asyncio.sleep(settings.POLL_INTERVAL_SEC)


na7la_hub = Na7laTCPHub()